from my_package.core.lidar_simulator import lidar, discretize_lidar, proximity_sensor
from my_package.core.geometry import is_rect_in_max_range, generate_random_obstacle, is_segment_visible